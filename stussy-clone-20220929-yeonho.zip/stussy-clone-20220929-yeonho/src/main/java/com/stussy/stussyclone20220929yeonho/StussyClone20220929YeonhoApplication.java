package com.stussy.stussyclone20220929yeonho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StussyClone20220929YeonhoApplication {

	public static void main(String[] args) {
		SpringApplication.run(StussyClone20220929YeonhoApplication.class, args);
	}

}
