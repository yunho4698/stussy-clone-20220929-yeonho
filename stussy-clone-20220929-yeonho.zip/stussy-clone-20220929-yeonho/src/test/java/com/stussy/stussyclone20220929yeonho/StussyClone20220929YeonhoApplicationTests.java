package com.stussy.stussyclone20220929yeonho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StussyClone20220929YeonhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
